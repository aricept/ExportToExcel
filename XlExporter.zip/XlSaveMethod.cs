﻿namespace ExportToExcel
{
    public enum XlSaveMethod
    {
        Download,
        Local
    }
}